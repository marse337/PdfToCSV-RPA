Welcome to today's tutorial where we'll embark on a journey to convert PDFs to CSVs, automate the uploading of these CSVs, and finally, capture the results. And guess what? We're making it scalable!

Once you download the zipfolder- extract all the files to your desktop. Ensure that you've placed all the PDFs you want to convert in the PDFs subfolder. If you've stored them elsewhere, remember to update the file paths in OpenRPA accordingly. Launch OpenRPA and import the work flow called ReadCSVFilesYTCopy.xaml from the TextFormatter folder. There is one variable that needs to be updated in OpenRPA called "CSVFilePath". That is all you need to worry about, Save and Run the flow

Watch as we swiftly transform these PDFs into CSVs. Let's dive right into our first step – converting PDFs to CSVs. I have including the entire python script that shows how I am converting the PDFs into CSV files.

With our PDFs now in CSV format, RPA move on to step two.

We can reference all these freshly baked CSV files and turn them into an array.

Step three brings us to the RPA Challenge website. Get ready for some automation magic!

RPA will start the challenge and watch as the bot skillfully navigates through all ten rounds for each CSV upload. and does this 4 times since there are 4 PDFs

And for our grand finale, the last step – capturing the results.

Voilà! Here in OpenRPA's output console, you can see the results of our automation. Efficient, accurate, and scalable!


