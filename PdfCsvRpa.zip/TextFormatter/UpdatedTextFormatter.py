import os
import PyPDF2
import csv

# Get the absolute path of the script's directory
script_directory = os.path.dirname(os.path.abspath(__file__))

# Folder paths where the PDFs are located and the CSVs will be saved
pdf_folder_path = os.path.join(script_directory, 'PDFs')
csv_folder_path = os.path.join(script_directory, 'CSVoutput')


# Make sure output folder exists
if not os.path.exists(csv_folder_path):
    os.makedirs(csv_folder_path)

# Loop through each PDF file
for filename in os.listdir(pdf_folder_path):
    if filename.endswith('.pdf'):
        pdf_path = os.path.join(pdf_folder_path, filename)
        csv_path = os.path.join(csv_folder_path, filename.replace('.pdf', '.csv'))

        # Step 1: Extract Text from PDF
        # Open PDF file
        pdfFile = open(pdf_path, 'rb')

        # Create pdf reader object
        pdfReader = PyPDF2.PdfReader(pdfFile)

        # Initialize a variable to store the extracted text
        extracted_text = ""

        # Loop through pages
        for pageNum in range(len(pdfReader.pages)):
            # Get the page object
            pageObj = pdfReader.pages[pageNum]
            # Extract text
            pageText = pageObj.extract_text()
            # Add extracted text to the overall text
            extracted_text += pageText

        # Close PDF file  
        pdfFile.close()

        # Step 2: Process the Extracted Text
        # Replace newline characters with spaces and condense into one line
        one_line_text = extracted_text.replace("\n", "")
        # Split the string at each occurrence of double space
        split_text = one_line_text.split("  ")
        # Create data matrix
        data_matrix = [split_text[i:i+7] for i in range(0, len(split_text), 7)]

        # Step 3: Write to CSV
        # Write the data to a CSV file
        with open(csv_path, 'w', newline='') as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerows(data_matrix)

        print(f'Text extracted from {filename} and saved to {csv_path}')
